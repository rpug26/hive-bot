# Hive SupportBot 🐝

Telegram bot for **The Hive 🇬🇧 AIM/Small Cap** community.

Looks up AIM micro-cap stocks and replies with summary, status, red flags and next catalyst.  
Supports both plain tickers (`ALRT`) and hashtags (`#ALRT`).

---

## Fastest Deploy Options

### 1. Railway (Recommended – simplest)

1. Go to [https://railway.app](https://railway.app) → Login with GitHub
2. **New Project** → **Empty Project**
3. Click the new project → **Add Service** → **GitHub Repo**  
   (or drag & drop the files from this folder)
4. Open the service → **Variables** tab → Add:
   ```
   TELEGRAM_BOT_TOKEN = 7259408094:AAFzyjsBhgO3ruY0XHoGDyjXE1cFbbEdAV4
   ```
5. Railway detects the `Procfile` automatically and starts the bot
6. Done – bot stays online 24/7

### 2. Render

1. Go to [https://render.com](https://render.com) → **New** → **Background Worker**
2. Connect your GitHub repo (or upload these files)
3. Settings:
   - **Runtime**: Python 3
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `python bot.py`
4. Add Environment Variable:
   - Key: `TELEGRAM_BOT_TOKEN`
   - Value: `7259408094:AAFzyjsBhgO3ruY0XHoGDyjXE1cFbbEdAV4`
5. Create Worker → the bot will stay online

---

## Local Testing

```bash
pip install -r requirements.txt
export TELEGRAM_BOT_TOKEN="7259408094:AAFzyjsBhgO3ruY0XHoGDyjXE1cFbbEdAV4"
python bot.py
```

---

## Bot Commands

| Command     | Description                  |
|-------------|------------------------------|
| `/start`    | Welcome message              |
| `/help`     | What the bot can do          |
| `/tickers`  | List all loaded tickers      |
| `/faq`      | Common questions             |

Just send a ticker (`KEFI`, `#ALRT`, `AXL`…) and the bot replies with the notes.

---

## Notes

- Disable **Group Privacy** in @BotFather if you want the bot to see all messages in the group
- Nothing the bot says is financial advice – always DYOR
- For live Notion write (`#stockpick` → Notion database) we still need the Notion Integration token
